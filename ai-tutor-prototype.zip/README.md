# AI Tutor Prototype

This is a prototype of an AI-powered tutor designed for cross-curriculum use.